Readme File for Assignment 1

Platform : Google Colab

We have used Google Colab to implement and run our python scripts. All the required files for this assignment, i.e. the 
datasets, stop-words file, a models.py file for Infersent and were uploaded to Google Drive and this drive was mounted
on the Colab platform for it to be able to access these files.

In order to run the script, we need to ensure that all the necessary files are present on the drive that is being mounted.

List of Files:
Part 1:
1. CUAD_v1.zip - Contains the dataset of txt files
2. stop_words.txt - Taken from 'https://www.site.uottawa.ca/~diana/csi5180/StopWords', contains the stop words

Part 2:
1. sts2016-english-with-gs-v1.0.zip - Contains the dataset of txt files
2. enwiki_dbow/doc2vec.bin - This file is downloaded from 'https://cloudstor.aarnet.edu.au/plus/s/hpfhUC72NnKDxXw', this file is the pre-trained doc2vec model that is being loaded in the script
3. models.py - This file is a requirement for getting the model for InferSent. This can be downloaded from 'https://github.com/facebookresearch/InferSent/blob/main/models.py'


With the above files on the drive, the script Assignment1.ipynb can be run.





